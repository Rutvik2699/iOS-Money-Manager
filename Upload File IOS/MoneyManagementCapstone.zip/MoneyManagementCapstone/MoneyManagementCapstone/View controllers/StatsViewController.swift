import UIKit
import Charts

class StatsViewController: UIViewController {

  
    @IBOutlet var pieChartView: PieChartView!
    
   
    
    
  override func viewDidLoad() {
    super.viewDidLoad()
    let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
    let unitsSold = [10.0, 4.0, 6.0, 3.0, 12.0, 16.0]
      DataUpdateChart()
  }
    func DataUpdateChart()  {

        let chart = PieChartView(frame: self.view.frame)
        // 2. generate chart data entries
        let track = ["Income", "Expense", "Total", "Bank"]
        let money = [650, 456.13, 78.67, 856.52]

        var entries = [PieChartDataEntry]()
        for (index, value) in money.enumerated() {
            let entry = PieChartDataEntry()
            entry.y = value
            entry.label = track[index]
            entries.append( entry)
        }

        // 3. chart setup
        let set = PieChartDataSet( entries: entries, label: "Transactions")
        // this is custom extension method. Download the code for more details.
        var colors: [UIColor] = []

        for _ in 0..<money.count {
            let red = Double(arc4random_uniform(256))
            let green = Double(arc4random_uniform(256))
            let blue = Double(arc4random_uniform(256))
            let color = UIColor(red: CGFloat(red/255), green: CGFloat(green/255), blue: CGFloat(blue/255), alpha: 1)
            colors.append(color)
        }
        
        set.colors = colors
        let data = PieChartData(dataSet: set)
        chart.data = data
        chart.noDataText = "No data available"
        // user interaction
        chart.isUserInteractionEnabled = true

        let d = Description()
        chart.holeRadiusPercent = 0
        //d.text = "iOSCharts.io"
        chart.chartDescription = d
        //chart.centerText = "Transactions"
        //chart.holeRadiusPercent = 0.2
        chart.transparentCircleColor = UIColor.clear
        self.view.addSubview(chart)

    }
}
