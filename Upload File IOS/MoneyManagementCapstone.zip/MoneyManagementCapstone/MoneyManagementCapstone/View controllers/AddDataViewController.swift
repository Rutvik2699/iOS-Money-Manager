//
//  AddDataViewController.swift
//  MoneyManagementCapstone
//
//  Created by Satyam on 2022-04-08.
//
import Firebase
import UIKit

//This is add data view, the data which is fetched from the server and is showed in add data view controller
class AddDataViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var refData: DatabaseReference!
    
    
    @IBOutlet weak var tblTransactions: UITableView!
    
    //array list to store
    //new transaction model file is created
    var TransactionList = [TransactionModel]()
    
    //for rows
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return TransactionList.count
    }
    
    //extra code
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 220
    }
    
    
    
    //for column
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PulledDataTableViewCell
        
        //declared transaction model as transaction
        let Transaction: TransactionModel
        
        Transaction = TransactionList[indexPath.row]
        //whatever the text in the label is, it is set to individual categories
       cell.lblCategory.text = Transaction.Category
      cell.lblDate.text = Transaction.Date
        cell.lblNote.text = Transaction.Note
       cell.lblTypee.text = Transaction.Typee
        cell.lblAmount.text = Transaction.Amount
       cell.lblNumber.text = Transaction.Number
        
        return cell
    }
    
    //all the outlets are created for individual text field.
    @IBOutlet weak var textFieldDate: UITextField!
    
    
    @IBOutlet weak var textFieldNumber: UITextField!
    
    
    @IBOutlet weak var textFieldCategory: UITextField!
    
    
    @IBOutlet weak var textFieldTypee: UITextField!
    
    
    @IBOutlet weak var textFieldAmount: UITextField!
    
    @IBOutlet weak var textFieldNote: UITextField!
    
    @IBAction func buttonActionAdd(_ sender: Any) {
        addData()
    }
    
    @IBOutlet weak var labelOutputMessage: UILabel!
    
    //close button is at the top used to dismiss the controller
    @IBAction func closeButton(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //if the firebase is nil, configure the firebase
        if FirebaseApp.app() == nil{
            FirebaseApp.configure()
        }
       
        //firebase data send, send the data under the label Transactions
        refData = Database.database().reference().child("Transactions");
        //the time we read the data it is readed as snapshot.
        //data snapshot contains all the data
        refData.observe(DataEventType.value, with: {(snapshot) in
            if snapshot.childrenCount>0
            {
                self.TransactionList.removeAll()
                
                for Transactions in snapshot.children.allObjects as![DataSnapshot]{
                    let transactionObject = Transactions.value as? [String: AnyObject]
                    
                    //passing individual string as transaction object.
                    let dataNumber = transactionObject?["dataNumber"]
                    let dataTypee = transactionObject?["dataTypee"]
                    let dataDate = transactionObject?["dataDate"]
                    let dataCategory = transactionObject?["dataCategory"]
                    let dataAmount = transactionObject?["dataAmount"]
                    let dataNote = transactionObject?["dataNote"]
                    
                    let Transaction = TransactionModel(
                        Number: dataNumber as! String?,
                                                       Typee: dataTypee as! String?,
                                                       Date: dataDate as! String?,
                                                       Category: dataCategory as! String?,
                                                       Amount: dataAmount as! String?,
                                                       Note: dataNote as! String?)
                    self.TransactionList.append(Transaction)
                }
                
            self.tblTransactions.reloadData()
            }
        })
    }
    
    //add data function as strings. only Number is set to key as it generated unique que using autoID
    //setting the text taken from user to the output Transaction
    func addData(){
        let key = refData.childByAutoId().key
        let Transaction = [ "dataNumber": key,
                           "dataTypee": textFieldTypee.text! as String,
                            "dataDate": textFieldDate.text! as String,
                            "dataCategory" : textFieldCategory.text! as String,
                            "dataAmount" : textFieldAmount.text! as String,
                            "dataNote" : textFieldNote.text! as String]
        
        //setting the value of transaction as key
        refData.child(key!).setValue(Transaction)
        labelOutputMessage.text = "Data Added!"
    }
}
