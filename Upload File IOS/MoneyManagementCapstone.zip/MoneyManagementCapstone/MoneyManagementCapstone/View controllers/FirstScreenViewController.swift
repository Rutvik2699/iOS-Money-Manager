//
//  FirstScreenViewController.swift
//  MoneyManagementCapstone
//
//  Created by Satyam on 2022-04-15.
//

import Foundation
import UIKit
import Firebase
import FirebaseAuth
//import FirebaseAuthUI


class FirstScreenViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func loginTapped(_ sender: UIButton) {
//
//        //Get default UI object
//        let authUI = FUIAuth.defaultAuthUI()
//        guard authUI != nil else{
//
//            //Log the error
//            return
//        }
//        //Set outselves as the delegate
//        authUI?.delegate = self
//       // authUI?.providers=[FUIEmailAuthProvider()]
//        //Get a refrence to the auth UI view controller
//        let authViewController = authUI!.authViewController()
//        //Show it
//
//        present(authViewController, animated: true, completion: nil)
    }
    
    
}


//extension FirstScreenViewController: FUIAuthDelegate{
    
//    func authUI(_ authUI: FUIAuth, didSignInWith authDataResult: AuthDataResult?, error: Error?) {
//        
//        
//        //Check if there was an error
//        if error != nil {
//            //Log the error
//            return
//            
//        }
//    
//        //authDataResult?.user.uid
//        
//        performSegue(withIdentifier: "goHome", sender: self)
//        
//    }
//}
